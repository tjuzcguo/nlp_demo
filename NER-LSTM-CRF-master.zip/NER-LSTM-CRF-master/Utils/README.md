# Utils
## 1. train_word2vec_model.py
利用[gensim](https://radimrehurek.com/gensim/ "gensim")训练词向量，具体参数参考官方API。使用方法：
`python2/python3 train_word2vec_model.py path_to_corpus path_to_model`

## 2. trietree.py
构建Trie树，并实现查找功能，使用方法参见demo。

Updating...
